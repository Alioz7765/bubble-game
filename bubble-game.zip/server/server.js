const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const cors = require("cors");

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: "*",
  },
});

let players = [];

io.on("connection", (socket) => {
  console.log("🚀 لاعب متصل:", socket.id);

  const newPlayer = { id: socket.id, name: `لاعب-${players.length + 1}` };
  players.push(newPlayer);
  io.emit("playerJoined", newPlayer);

  socket.on("message", (msg) => {
    io.emit("message", `${newPlayer.name}: ${msg}`);
  });

  socket.on("disconnect", () => {
    console.log("❌ لاعب غادر:", socket.id);
    players = players.filter((player) => player.id !== socket.id);
    io.emit("playerLeft", socket.id);
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`🎮 الخادم يعمل على المنفذ ${PORT}`);
});
