import React, { useState, useEffect } from "react";
import io from "socket.io-client";

const SERVER_URL = "https://coller1.onrender.com"; 

const socket = io(SERVER_URL);

function App() {
  const [players, setPlayers] = useState([]);
  const [message, setMessage] = useState("");
  const [chat, setChat] = useState([]);

  useEffect(() => {
    socket.on("playerJoined", (player) => {
      setPlayers((prevPlayers) => [...prevPlayers, player]);
    });

    socket.on("message", (msg) => {
      setChat((prevChat) => [...prevChat, msg]);
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const sendMessage = () => {
    if (message.trim() !== "") {
      socket.emit("message", message);
      setMessage("");
    }
  };

  return (
    <div style={{ textAlign: "center", fontFamily: "Arial, sans-serif" }}>
      <h1>لعبة الفقاعات 🎈</h1>

      <h2>🧑‍🤝‍🧑 اللاعبون المتصلون:</h2>
      <ul>
        {players.map((player, index) => (
          <li key={index}>{player.name}</li>
        ))}
      </ul>

      <h2>💬 الدردشة داخل اللعبة:</h2>
      <div style={{
        border: "1px solid #ccc",
        padding: "10px",
        maxWidth: "300px",
        margin: "auto",
        height: "150px",
        overflowY: "scroll",
      }}>
        {chat.map((msg, index) => (
          <p key={index}>{msg}</p>
        ))}
      </div>

      <input
        type="text"
        value={message}
        onChange={(e) => setMessage(e.target.value)}
        placeholder="اكتب رسالة..."
        style={{ padding: "5px", marginTop: "10px" }}
      />
      <button onClick={sendMessage} style={{ marginLeft: "5px" }}>
        إرسال 🚀
      </button>
    </div>
  );
}

export default App;
